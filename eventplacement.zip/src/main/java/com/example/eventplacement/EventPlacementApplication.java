package com.example.eventplacement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EventPlacementApplication {

    public static void main(String[] args) {
        SpringApplication.run(EventPlacementApplication.class, args);
    }

}
