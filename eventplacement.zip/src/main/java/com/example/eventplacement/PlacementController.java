package com.example.eventplacement;

import org.springframework.web.bind.annotation.*;

@RestController
@CrossOrigin
public class PlacementController {

    @GetMapping("/solve")
    public int[] solve(@RequestParam int n) {
        int[] placement = new int[n];

        solveNQueens(placement, 0, n);
        return placement;
    }

    private boolean solveNQueens(int[] placement, int row, int n) {
        if (row == n) return true;

        for (int col = 0; col < n; col++) {
            if (isSafe(placement, row, col)) {
                placement[row] = col;

                if (solveNQueens(placement, row + 1, n)) {
                    return true;
                }
            }
        }
        return false;
    }

    private boolean isSafe(int[] placement, int row, int col) {
        for (int i = 0; i < row; i++) {
            int placedCol = placement[i];

            if (placedCol == col ||
                    Math.abs(placedCol - col) == Math.abs(i - row)) {
                return false;
            }
        }
        return true;
    }
}