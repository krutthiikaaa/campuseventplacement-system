package com.example.eventplacement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EventPlacementApplicationTests {

    @Test
    void contextLoads() {
    }

}
